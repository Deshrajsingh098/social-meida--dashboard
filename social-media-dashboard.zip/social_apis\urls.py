from django.urls import path
from . import views

app_name = 'social_apis'

urlpatterns = [
    path('twitter/callback/', views.twitter_callback, name='twitter_callback'),
    path('facebook/callback/', views.facebook_callback, name='facebook_callback'),
    path('instagram/callback/', views.instagram_callback, name='instagram_callback'),
    path('tokens/', views.token_list, name='token_list'),
    path('tokens/<int:pk>/refresh/', views.refresh_token, name='refresh_token'),
    path('tokens/<int:pk>/revoke/', views.revoke_token, name='revoke_token'),
    path('logs/', views.api_logs, name='api_logs'),
] 