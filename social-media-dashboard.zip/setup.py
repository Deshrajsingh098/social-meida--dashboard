import os
import sys
import subprocess
import platform

def create_virtual_environment():
    print("Creating virtual environment...")
    subprocess.run([sys.executable, "-m", "venv", "venv"])

def activate_virtual_environment():
    if platform.system() == "Windows":
        activate_script = os.path.join("venv", "Scripts", "activate")
    else:
        activate_script = os.path.join("venv", "bin", "activate")
    
    if platform.system() == "Windows":
        subprocess.run(["cmd", "/c", activate_script])
    else:
        subprocess.run(["source", activate_script])

def install_requirements():
    print("Installing requirements...")
    if platform.system() == "Windows":
        subprocess.run(["venv\\Scripts\\pip", "install", "-r", "requirements.txt"])
    else:
        subprocess.run(["venv/bin/pip", "install", "-r", "requirements.txt"])

def create_env_file():
    print("Creating .env file...")
    env_content = """DEBUG=True
SECRET_KEY=your-secret-key-here
DATABASE_URL=sqlite:///db.sqlite3
"""
    with open(".env", "w") as f:
        f.write(env_content)

def run_migrations():
    print("Running migrations...")
    if platform.system() == "Windows":
        subprocess.run(["venv\\Scripts\\python", "manage.py", "migrate"])
    else:
        subprocess.run(["venv/bin/python", "manage.py", "migrate"])

def main():
    print("Setting up Social Media Dashboard...")
    
    # Create virtual environment
    create_virtual_environment()
    
    # Install requirements
    install_requirements()
    
    # Create .env file if it doesn't exist
    if not os.path.exists(".env"):
        create_env_file()
    
    # Run migrations
    run_migrations()
    
    print("\nSetup completed successfully!")
    print("\nNext steps:")
    print("1. Activate the virtual environment:")
    if platform.system() == "Windows":
        print("   venv\\Scripts\\activate")
    else:
        print("   source venv/bin/activate")
    print("2. Create a superuser:")
    print("   python manage.py createsuperuser")
    print("3. Run the development server:")
    print("   python manage.py runserver")
    print("4. Access the application at http://localhost:8000")

if __name__ == "__main__":
    main() 