from django import forms
from .models import UserProfile

class UserProfileForm(forms.ModelForm):
    """Form for editing user profile"""
    class Meta:
        model = UserProfile
        fields = ['profile_picture', 'bio', 'website', 'location']
        widgets = {
            'bio': forms.Textarea(attrs={'rows': 4}),
        } 