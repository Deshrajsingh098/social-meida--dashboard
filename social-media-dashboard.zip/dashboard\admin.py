from django.contrib import admin
from .models import SocialPost, PostInteraction, Analytics

@admin.register(SocialPost)
class SocialPostAdmin(admin.ModelAdmin):
    list_display = ('user', 'platform', 'status', 'scheduled_time', 'published_time', 'created_at')
    list_filter = ('platform', 'status', 'user')
    search_fields = ('content', 'user__username')
    date_hierarchy = 'created_at'
    readonly_fields = ('created_at', 'updated_at', 'published_time')
    fieldsets = (
        (None, {
            'fields': ('user', 'content', 'image', 'platform')
        }),
        ('Status Information', {
            'fields': ('status', 'scheduled_time', 'published_time', 'platform_post_id')
        }),
        ('Timestamps', {
            'fields': ('created_at', 'updated_at'),
            'classes': ('collapse',)
        }),
    )

@admin.register(PostInteraction)
class PostInteractionAdmin(admin.ModelAdmin):
    list_display = ('user', 'post', 'interaction_type', 'created_at')
    list_filter = ('interaction_type', 'user', 'post__platform')
    search_fields = ('content', 'user__username', 'post__content')
    date_hierarchy = 'created_at'
    readonly_fields = ('created_at',)

@admin.register(Analytics)
class AnalyticsAdmin(admin.ModelAdmin):
    list_display = ('post', 'likes_count', 'comments_count', 'shares_count', 'views_count', 'engagement_rate', 'recorded_at')
    list_filter = ('post__platform', 'post__user')
    search_fields = ('post__content', 'post__user__username')
    date_hierarchy = 'recorded_at'
    readonly_fields = ('recorded_at',)
