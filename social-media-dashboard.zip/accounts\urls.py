from django.urls import path
from . import views

app_name = 'accounts'

urlpatterns = [
    path('profile/', views.profile_view, name='profile'),
    path('profile/edit/', views.profile_edit, name='profile_edit'),
    path('connect/twitter/', views.connect_twitter, name='connect_twitter'),
    path('connect/facebook/', views.connect_facebook, name='connect_facebook'),
    path('connect/instagram/', views.connect_instagram, name='connect_instagram'),
    path('disconnect/<str:platform>/', views.disconnect_social, name='disconnect_social'),
] 