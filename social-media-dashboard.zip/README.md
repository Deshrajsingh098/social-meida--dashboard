# Social Media Dashboard

A Django-based social media dashboard that allows users to manage and analyze their social media accounts.

## Features

- User authentication (login/register)
- Social media account integration
- Analytics dashboard
- API logging and monitoring

## Setup Instructions

1. Create a virtual environment:
```bash
python -m venv venv
```

2. Activate the virtual environment:
- Windows:
```bash
venv\Scripts\activate
```
- Linux/Mac:
```bash
source venv/bin/activate
```

3. Install dependencies:
```bash
pip install -r requirements.txt
```

4. Set up environment variables:
Create a `.env` file in the root directory with the following variables:
```
DEBUG=True
SECRET_KEY=your-secret-key
DATABASE_URL=sqlite:///db.sqlite3
```

5. Run migrations:
```bash
python manage.py migrate
```

6. Create a superuser:
```bash
python manage.py createsuperuser
```

7. Run the development server:
```bash
python manage.py runserver
```

8. Access the application at http://localhost:8000

## Project Structure

- `accounts/` - User authentication and profile management
- `social_apis/` - Social media API integrations
- `dashboard/` - Main dashboard views and templates
- `templates/` - Base templates and shared components

## Contributing

1. Fork the repository
2. Create a new branch
3. Make your changes
4. Submit a pull request

## License

This project is licensed under the MIT License. 