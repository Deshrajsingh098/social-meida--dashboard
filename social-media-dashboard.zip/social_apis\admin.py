from django.contrib import admin
from social_apis.models import SocialMediaToken, APILog

@admin.register(SocialMediaToken)
class SocialMediaTokenAdmin(admin.ModelAdmin):
    list_display = ('user', 'platform', 'is_active', 'token_expires_at', 'updated_at')
    list_filter = ('platform', 'is_active', 'user')
    search_fields = ('user__username',)
    date_hierarchy = 'updated_at'
    readonly_fields = ('created_at', 'updated_at')
    fieldsets = (
        (None, {
            'fields': ('user', 'platform', 'is_active')
        }),
        ('Token Information', {
            'fields': ('access_token', 'access_token_secret', 'refresh_token', 'token_expires_at'),
            'classes': ('collapse',)
        }),
        ('Timestamps', {
            'fields': ('created_at', 'updated_at'),
            'classes': ('collapse',)
        }),
    )

@admin.register(APILog)
class APILogAdmin(admin.ModelAdmin):
    list_display = ('user', 'platform', 'endpoint', 'method', 'status', 'response_code', 'created_at')
    list_filter = ('platform', 'status', 'method', 'user')
    search_fields = ('endpoint', 'user__username', 'error_message')
    date_hierarchy = 'created_at'
    readonly_fields = ('created_at',)
    fieldsets = (
        (None, {
            'fields': ('user', 'platform', 'endpoint', 'method', 'status')
        }),
        ('Response Information', {
            'fields': ('response_code', 'error_message'),
            'classes': ('collapse',)
        }),
        ('Timestamps', {
            'fields': ('created_at',),
            'classes': ('collapse',)
        }),
    )
