from django.shortcuts import render, redirect, get_object_or_404
from django.contrib.auth.decorators import login_required
from django.contrib import messages
from django.urls import reverse
from django.http import HttpResponseRedirect
from .models import UserProfile
from .forms import UserProfileForm
from social_apis.models import SocialMediaToken
from allauth.socialaccount.models import SocialAccount

@login_required
def profile_view(request):
    """View for displaying user profile"""
    profile = request.user.userprofile
    social_accounts = SocialAccount.objects.filter(user=request.user)
    tokens = SocialMediaToken.objects.filter(user=request.user)
    
    context = {
        'profile': profile,
        'social_accounts': social_accounts,
        'tokens': tokens,
    }
    return render(request, 'accounts/profile.html', context)

@login_required
def profile_edit(request):
    """View for editing user profile"""
    profile = request.user.userprofile
    
    if request.method == 'POST':
        form = UserProfileForm(request.POST, request.FILES, instance=profile)
        if form.is_valid():
            form.save()
            messages.success(request, 'Profile updated successfully!')
            return redirect('accounts:profile')
    else:
        form = UserProfileForm(instance=profile)
    
    return render(request, 'accounts/profile_edit.html', {'form': form})

@login_required
def connect_twitter(request):
    """View for connecting Twitter account"""
    # TODO: Implement Twitter OAuth
    messages.info(request, 'Twitter connection coming soon!')
    return redirect('accounts:profile')

@login_required
def connect_facebook(request):
    """View for connecting Facebook account"""
    # TODO: Implement Facebook OAuth
    messages.info(request, 'Facebook connection coming soon!')
    return redirect('accounts:profile')

@login_required
def connect_instagram(request):
    """View for connecting Instagram account"""
    # TODO: Implement Instagram OAuth
    messages.info(request, 'Instagram connection coming soon!')
    return redirect('accounts:profile')

@login_required
def disconnect_social(request, platform):
    """View for disconnecting a social media account"""
    profile = request.user.userprofile
    
    if platform == 'twitter':
        profile.twitter_connected = False
        profile.twitter_access_token = None
    elif platform == 'facebook':
        profile.facebook_connected = False
        profile.facebook_access_token = None
    elif platform == 'instagram':
        profile.instagram_connected = False
        profile.instagram_access_token = None
    else:
        messages.error(request, 'Invalid platform specified.')
        return redirect('accounts:profile')
    
    profile.save()
    messages.success(request, f'{platform.title()} disconnected successfully!')
    return redirect('accounts:profile')
