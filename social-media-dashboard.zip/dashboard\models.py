from django.db import models
from django.contrib.auth.models import User
from django.utils import timezone

class SocialPost(models.Model):
    PLATFORM_CHOICES = [
        ('twitter', 'Twitter'),
        ('facebook', 'Facebook'),
        ('instagram', 'Instagram'),
    ]

    STATUS_CHOICES = [
        ('draft', 'Draft'),
        ('scheduled', 'Scheduled'),
        ('published', 'Published'),
        ('failed', 'Failed'),
    ]

    user = models.ForeignKey(User, on_delete=models.CASCADE, related_name='posts')
    content = models.TextField()
    image = models.ImageField(upload_to='post_images/', blank=True, null=True)
    platform = models.CharField(max_length=20, choices=PLATFORM_CHOICES)
    status = models.CharField(max_length=20, choices=STATUS_CHOICES, default='draft')
    scheduled_time = models.DateTimeField(null=True, blank=True)
    published_time = models.DateTimeField(null=True, blank=True)
    platform_post_id = models.CharField(max_length=100, blank=True, null=True)
    created_at = models.DateTimeField(auto_now_add=True)
    updated_at = models.DateTimeField(auto_now=True)

    def __str__(self):
        return f"{self.user.username}'s {self.platform} post - {self.created_at}"

    class Meta:
        ordering = ['-created_at']

class PostInteraction(models.Model):
    INTERACTION_TYPES = [
        ('like', 'Like'),
        ('comment', 'Comment'),
        ('share', 'Share'),
    ]

    post = models.ForeignKey(SocialPost, on_delete=models.CASCADE, related_name='interactions')
    user = models.ForeignKey(User, on_delete=models.CASCADE, related_name='interactions')
    interaction_type = models.CharField(max_length=20, choices=INTERACTION_TYPES)
    content = models.TextField(blank=True, null=True)  # For comments
    platform_interaction_id = models.CharField(max_length=100, blank=True, null=True)
    created_at = models.DateTimeField(auto_now_add=True)

    def __str__(self):
        return f"{self.user.username} {self.interaction_type} on {self.post}"

    class Meta:
        ordering = ['-created_at']
        unique_together = ['post', 'user', 'interaction_type']

class Analytics(models.Model):
    post = models.ForeignKey(SocialPost, on_delete=models.CASCADE, related_name='analytics')
    likes_count = models.IntegerField(default=0)
    comments_count = models.IntegerField(default=0)
    shares_count = models.IntegerField(default=0)
    views_count = models.IntegerField(default=0)
    engagement_rate = models.FloatField(default=0.0)
    recorded_at = models.DateTimeField(default=timezone.now)

    def __str__(self):
        return f"Analytics for {self.post} - {self.recorded_at}"

    class Meta:
        verbose_name_plural = 'Analytics'
        ordering = ['-recorded_at']
