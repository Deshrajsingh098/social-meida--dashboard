from django.apps import AppConfig


class SocialApisConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'social_apis'
