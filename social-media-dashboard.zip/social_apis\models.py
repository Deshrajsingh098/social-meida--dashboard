from django.db import models
from django.contrib.auth.models import User
from django.utils import timezone

class SocialMediaToken(models.Model):
    PLATFORM_CHOICES = [
        ('twitter', 'Twitter'),
        ('facebook', 'Facebook'),
        ('instagram', 'Instagram'),
    ]

    user = models.ForeignKey(User, on_delete=models.CASCADE, related_name='social_tokens')
    platform = models.CharField(max_length=20, choices=PLATFORM_CHOICES)
    access_token = models.CharField(max_length=255)
    access_token_secret = models.CharField(max_length=255, blank=True, null=True)
    refresh_token = models.CharField(max_length=255, blank=True, null=True)
    token_expires_at = models.DateTimeField(null=True, blank=True)
    is_active = models.BooleanField(default=True)
    created_at = models.DateTimeField(auto_now_add=True)
    updated_at = models.DateTimeField(auto_now=True)

    def __str__(self):
        return f"{self.user.username}'s {self.platform} token"

    class Meta:
        unique_together = ['user', 'platform']
        ordering = ['-updated_at']

    def is_expired(self):
        if not self.token_expires_at:
            return False
        return timezone.now() >= self.token_expires_at

class APILog(models.Model):
    STATUS_CHOICES = [
        ('success', 'Success'),
        ('error', 'Error'),
        ('warning', 'Warning'),
    ]

    user = models.ForeignKey(User, on_delete=models.CASCADE, related_name='api_logs')
    platform = models.CharField(max_length=20, choices=SocialMediaToken.PLATFORM_CHOICES)
    endpoint = models.CharField(max_length=255)
    method = models.CharField(max_length=10)
    status = models.CharField(max_length=20, choices=STATUS_CHOICES)
    response_code = models.IntegerField(null=True, blank=True)
    error_message = models.TextField(blank=True, null=True)
    created_at = models.DateTimeField(auto_now_add=True)

    def __str__(self):
        return f"{self.user.username} - {self.platform} API call - {self.created_at}"

    class Meta:
        ordering = ['-created_at']
